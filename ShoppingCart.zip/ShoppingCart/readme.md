# Shopping Cart Demo Application
## Angular / .NET Core

This application demonstrates a basic online shopping experience using an Angular front-end and .NET Core back-end.  The user can:
- Browse a list of products.
- Add products to the cart in various quantities.
- View the cart.
- Modify product quantities in the cart.
- Remove products from the cart.
- Place an order via the check-out process:
	- Enter billing information.
	- Enter shipping information.
	- Review the order.
	- Receive confirmation of the order.
	
## Starting the Application

- Verify angular-cli and dotnet core are installed.
	- https://cli.angular.io/
	- https://dotnet.microsoft.com/download
	
- Open a terminal/cmd window and execute:

	````
	cd shopping-cart
	ng serve
	````

- Open a second terminal/cmd window and execute:

	````
	cd ShoppingCart.Api/ShoppingCart.Api
	dotnet run
	````
	
- Open http://localhost:4200 in the browser.

