import { ProductSelection } from './product-selection';

describe('ProductSelection', () => {
  it('should create an instance', () => {
    expect(new ProductSelection()).toBeTruthy();
  });
});
