﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCart.Api.Configuration
{
    public class CorsSettings
    {
        public string AngularAppUrl { get; set; }
    }
}
